export default function ManualRunsPage() {
  return <div>Runs Pages</div>;
}
