export default function HomePage() {
  return <div>Home page</div>;
}
