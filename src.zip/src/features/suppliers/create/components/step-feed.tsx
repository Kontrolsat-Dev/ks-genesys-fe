import { useEffect } from "react";
import { useFormContext } from "react-hook-form";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";

type Kind = "http" | "ftp";

type Props = {
  tabKind?: Kind;
  setTabKind?: (k: Kind) => void;
};

export default function FeedOrigin({ tabKind, setTabKind }: Props) {
  const form = useFormContext();
  const format = form.watch("format") as "csv" | "json" | "xml" | undefined;

  // kind vindo do form (fallback)
  const formKind = form.watch("kind") as Kind | undefined;

  // prioridade: prop controlada -> form -> "http"
  const effectiveKind: Kind = tabKind ?? formKind ?? "http";
  const isFtp = effectiveKind === "ftp";

  // garantir que o form.kind está sempre alinhado
  useEffect(() => {
    if (!formKind) {
      form.setValue("kind", effectiveKind, { shouldDirty: false });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (format === "csv") {
      const cur = form.getValues("csv_delimiter");
      if (!cur) form.setValue("csv_delimiter", ",", { shouldDirty: true });
    } else {
      form.setValue("csv_delimiter", null, { shouldDirty: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [format]);

  const handleTabChange = (v: string) => {
    const k = v as Kind;
    form.setValue("kind", k, { shouldDirty: true });
    setTabKind?.(k);
  };

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h3 className="text-xl font-medium">Conexão do feed</h3>
          <p className="text-xs text-muted-foreground">
            Configura a origem e testa antes de guardar.
          </p>
        </div>

        <Tabs value={effectiveKind} onValueChange={handleTabChange}>
          <TabsList>
            <TabsTrigger value="http">HTTP</TabsTrigger>
            <TabsTrigger value="ftp">FTP</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-9">
          <FormField
            control={form.control}
            name="url"
            render={({ field }) => (
              <FormItem>
                <FormLabel>
                  {isFtp ? "Caminho remoto" : "URL"}
                  <span className="ml-1 text-xs text-muted-foreground block">
                    {isFtp ? (
                      <>
                        Diretório ou ficheiro no servidor FTP (ex.:{" "}
                        <code>.</code> ou <code>/feeds/produtos.csv</code>).
                        Host/porta e credenciais vêm do bloco de autenticação.
                      </>
                    ) : (
                      <>
                        CSV/JSON (e XML para referência). Confirma o delimitador
                        quando CSV.
                      </>
                    )}
                  </span>
                </FormLabel>
                <FormControl>
                  <Input
                    className="h-10"
                    placeholder={
                      isFtp
                        ? "./ ou /caminho/ficheiro.csv"
                        : "https://exemplo.com/feed.csv"
                    }
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="md:col-span-3 flex items-end">
          <FormField
            control={form.control}
            name="active"
            render={({ field }) => (
              <FormItem className="w-full">
                <FormLabel>Estado</FormLabel>
                <div className="h-10 w-full rounded-md border px-3 flex items-center justify-between">
                  <span className="text-sm">Ativo</span>
                  <FormControl>
                    <Switch
                      checked={!!field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="flex flex-wrap items-end gap-4">
        <FormField
          control={form.control}
          name="format"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Formato</FormLabel>
              <FormControl>
                <Select
                  value={field.value ?? ""}
                  onValueChange={field.onChange}
                >
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="csv/json" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="csv">CSV</SelectItem>
                    <SelectItem value="json">JSON</SelectItem>
                    <SelectItem value="xml">XML</SelectItem>
                  </SelectContent>
                </Select>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {format === "csv" && (
          <FormField
            control={form.control}
            name="csv_delimiter"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Delimitador</FormLabel>
                <FormControl>
                  <Select
                    value={field.value ?? ","}
                    onValueChange={field.onChange}
                  >
                    <SelectTrigger className="h-10 w-[120px]">
                      <SelectValue placeholder="delim" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=",">,</SelectItem>
                      <SelectItem value=";">;</SelectItem>
                      <SelectItem value="|">|</SelectItem>
                      <SelectItem value="\t">tab</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
      </div>
    </section>
  );
}
