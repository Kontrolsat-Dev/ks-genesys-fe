import { BrandsService } from "./service";

export const brandsClient = new BrandsService();

export * from "./types";
