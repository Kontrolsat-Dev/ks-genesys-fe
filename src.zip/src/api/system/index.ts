import { SystemService } from "./service";

export const systemClient = new SystemService(/* http */);

export * from "./types";
