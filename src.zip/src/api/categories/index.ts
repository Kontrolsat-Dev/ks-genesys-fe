import { CategoriesService } from "./service";

export const categoriesClient = new CategoriesService();

export * from "./types";
